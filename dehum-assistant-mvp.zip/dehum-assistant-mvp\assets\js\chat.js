jQuery(document).ready(function ($) {
  'use strict';

  // Chat widget functionality
  const ChatWidget = {
    isOpen: false,
    conversationHistory: [],

    init: function () {
      this.bindEvents();
      this.loadConversationHistory();
      this.updateCharCounter();
    },

    bindEvents: function () {
      // Open chat when button is clicked
      $('#dehum-mvp-chat-button').on('click', this.openChat.bind(this));

      // Close chat when X is clicked
      $('#dehum-mvp-close-chat').on('click', this.closeChat.bind(this));

      // Send message when Send button is clicked
      $('#dehum-mvp-send-button').on('click', this.sendMessage.bind(this));

      // Send message when Enter is pressed (Shift+Enter for new line)
      $('#dehum-mvp-chat-input').on('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          ChatWidget.sendMessage();
        }
      });

      // Update character counter
      $('#dehum-mvp-chat-input').on('input', this.updateCharCounter.bind(this));

      // Close chat when clicking outside (optional)
      $(document).on('click', function (e) {
        if (ChatWidget.isOpen &&
          !$(e.target).closest('#dehum-mvp-chat-modal, #dehum-mvp-chat-button').length) {
          // Uncomment to enable click-outside-to-close
          // ChatWidget.closeChat();
        }
      });
    },

    openChat: function () {
      $('#dehum-mvp-chat-modal').fadeIn(300);
      $('#dehum-mvp-chat-button').hide();
      this.isOpen = true;

      // Focus on input
      setTimeout(() => {
        $('#dehum-mvp-chat-input').focus();
      }, 350);

      // Scroll to bottom
      this.scrollToBottom();
    },

    closeChat: function () {
      $('#dehum-mvp-chat-modal').fadeOut(300);
      $('#dehum-mvp-chat-button').show();
      this.isOpen = false;
    },

    sendMessage: function () {
      const input = $('#dehum-mvp-chat-input');
      const message = input.val().trim();

      if (!message) {
        return;
      }

      if (message.length > 400) {
        this.showError('Message too long. Please keep it under 400 characters.');
        return;
      }

      // Clear input and disable send button
      input.val('');
      this.updateCharCounter();
      this.setInputState(false);

      // Add user message to chat
      this.addMessage(message, 'user');

      // Show typing indicator
      this.showTypingIndicator();

      // Send to WordPress AJAX
      this.sendToWordPress(message);
    },

    sendToWordPress: function (message) {
      $.ajax({
        url: dehumMVP.ajaxUrl,
        type: 'POST',
        data: {
          action: 'dehum_mvp_chat',
          message: message,
          nonce: dehumMVP.nonce
        },
        success: function (response) {
          ChatWidget.hideTypingIndicator();

          if (response.success) {
            ChatWidget.addMessage(response.data.response, 'assistant');
            ChatWidget.saveConversationHistory();
          } else {
            ChatWidget.showError(response.data.message || 'Something went wrong. Please try again.');
          }

          ChatWidget.setInputState(true);
        },
        error: function (xhr, status, error) {
          ChatWidget.hideTypingIndicator();
          ChatWidget.showError('Connection failed. Please check your internet and try again.');
          ChatWidget.setInputState(true);

          console.error('AJAX Error:', { xhr, status, error });
        }
      });
    },

    addMessage: function (message, type) {
      const messagesContainer = $('#dehum-mvp-chat-messages');
      const messageClass = type === 'user' ? 'user-message' : 'assistant-message';

      const messageHtml = `<div class="${messageClass}">${this.escapeHtml(message)}</div>`;
      messagesContainer.append(messageHtml);

      // Save to conversation history
      this.conversationHistory.push({
        message: message,
        type: type,
        timestamp: new Date().toISOString()
      });

      this.scrollToBottom();
    },

    showTypingIndicator: function () {
      const messagesContainer = $('#dehum-mvp-chat-messages');
      const typingHtml = `
                <div class="typing-indicator" id="typing-indicator">
                    <div class="typing-spinner"></div>
                    <span>${dehumMVP.strings.typing}</span>
                </div>
            `;
      messagesContainer.append(typingHtml);
      this.scrollToBottom();
    },

    hideTypingIndicator: function () {
      $('#typing-indicator').remove();
    },

    showError: function (errorMessage) {
      const messagesContainer = $('#dehum-mvp-chat-messages');
      const errorHtml = `<div class="error-message">${this.escapeHtml(errorMessage)}</div>`;
      messagesContainer.append(errorHtml);
      this.scrollToBottom();
    },

    setInputState: function (enabled) {
      const input = $('#dehum-mvp-chat-input');
      const button = $('#dehum-mvp-send-button');

      if (enabled) {
        input.prop('disabled', false);
        button.prop('disabled', false).text(dehumMVP.strings.sendButton);
        input.focus();
      } else {
        input.prop('disabled', true);
        button.prop('disabled', true).text('Sending...');
      }
    },

    updateCharCounter: function () {
      const input = $('#dehum-mvp-chat-input');
      const counter = $('#char-count');
      const length = input.val().length;

      counter.text(length);

      // Change color if approaching limit
      if (length > 350) {
        counter.css('color', '#f44336');
      } else if (length > 300) {
        counter.css('color', '#ff9800');
      } else {
        counter.css('color', '#666');
      }
    },

    scrollToBottom: function () {
      const messagesContainer = $('#dehum-mvp-chat-messages');
      messagesContainer.scrollTop(messagesContainer[0].scrollHeight);
    },

    saveConversationHistory: function () {
      localStorage.setItem('dehum_mvp_conversation', JSON.stringify(this.conversationHistory));
    },

    loadConversationHistory: function () {
      const saved = localStorage.getItem('dehum_mvp_conversation');
      if (saved) {
        try {
          this.conversationHistory = JSON.parse(saved);
          this.displayConversationHistory();
        } catch (e) {
          console.warn('Failed to load conversation history:', e);
          this.conversationHistory = [];
        }
      }
    },

    displayConversationHistory: function () {
      const messagesContainer = $('#dehum-mvp-chat-messages');

      // Clear existing messages except welcome message
      messagesContainer.find('.user-message, .assistant-message').not(':first').remove();

      // Display saved messages
      this.conversationHistory.forEach(item => {
        if (item.type === 'user' || item.type === 'assistant') {
          const messageClass = item.type === 'user' ? 'user-message' : 'assistant-message';
          const messageHtml = `<div class="${messageClass}">${this.escapeHtml(item.message)}</div>`;
          messagesContainer.append(messageHtml);
        }
      });

      this.scrollToBottom();
    },

    clearHistory: function () {
      this.conversationHistory = [];
      localStorage.removeItem('dehum_mvp_conversation');

      // Clear messages except welcome message
      const messagesContainer = $('#dehum-mvp-chat-messages');
      messagesContainer.find('.user-message, .assistant-message').not(':first').remove();
    },

    escapeHtml: function (text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }
  };

  // Initialize chat widget
  ChatWidget.init();

  // Make ChatWidget available globally for debugging
  window.DehumChatWidget = ChatWidget;

  // Console message for developers
  console.log('Dehumidifier Assistant MVP loaded successfully!');
}); 