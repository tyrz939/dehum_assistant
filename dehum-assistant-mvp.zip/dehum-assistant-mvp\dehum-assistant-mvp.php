<?php
/**
 * Plugin Name: Dehumidifier Assistant MVP
 * Plugin URI: https://github.com/your-username/dehum-assistant
 * Description: Minimal viable chat widget that connects to n8n workflow for dehumidifier sizing assistance
 * Version: 1.0.0
 * Author: Your Name
 * License: MIT
 * Text Domain: dehum-assistant-mvp
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('DEHUM_MVP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DEHUM_MVP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('DEHUM_MVP_VERSION', '1.0.0');

/**
 * Main Dehumidifier Assistant MVP Class
 */
class DehumidifierAssistantMVP {
    
    public function __construct() {
        add_action('init', [$this, 'init']);
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
    }
    
    public function init() {
        // Enqueue frontend assets
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        
        // Add chat widget to footer
        add_action('wp_footer', [$this, 'render_chat_widget']);
        
        // AJAX handlers for chat functionality
        add_action('wp_ajax_dehum_mvp_chat', [$this, 'handle_chat_message']);
        add_action('wp_ajax_nopriv_dehum_mvp_chat', [$this, 'handle_chat_message']);
        
        // Admin notices for Step 1.2 testing
        add_action('admin_notices', [$this, 'admin_activation_notice']);
        
        // Load textdomain for translations
        load_plugin_textdomain('dehum-assistant-mvp', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    public function enqueue_frontend_assets() {
        // Enqueue CSS
        wp_enqueue_style(
            'dehum-mvp-chat',
            DEHUM_MVP_PLUGIN_URL . 'assets/css/chat.css',
            [],
            DEHUM_MVP_VERSION
        );
        
        // Enqueue JavaScript
        wp_enqueue_script(
            'dehum-mvp-chat',
            DEHUM_MVP_PLUGIN_URL . 'assets/js/chat.js',
            ['jquery'],
            DEHUM_MVP_VERSION,
            true
        );
        
        // Localize script for AJAX
        wp_localize_script('dehum-mvp-chat', 'dehumMVP', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dehum_mvp_chat_nonce'),
            'strings' => [
                'sendButton' => __('Send', 'dehum-assistant-mvp'),
                'placeholder' => __('Ask about dehumidifier sizing...', 'dehum-assistant-mvp'),
                'error' => __('Sorry, something went wrong. Please try again.', 'dehum-assistant-mvp'),
                'typing' => __('Assistant is typing...', 'dehum-assistant-mvp')
            ]
        ]);
    }
    
    public function render_chat_widget() {
        // Only show on frontend, not in admin
        if (is_admin()) {
            return;
        }
        
        ?>
        <div id="dehum-mvp-chat-widget">
            <!-- Chat button -->
            <div id="dehum-mvp-chat-button">
                <span>💬</span>
                <span class="chat-text">Dehumidifier Help</span>
            </div>
            
            <!-- Chat modal (hidden initially) -->
            <div id="dehum-mvp-chat-modal" style="display: none;">
                <div class="chat-header">
                    <h3>Dehumidifier Assistant</h3>
                    <button id="dehum-mvp-close-chat">&times;</button>
                </div>
                <div class="chat-messages" id="dehum-mvp-chat-messages">
                    <div class="assistant-message">
                        Hello! I'm your Dehumidifier Assistant. Ask me anything about sizing or model selection.
                    </div>
                </div>
                <div class="chat-input-area">
                    <textarea 
                        id="dehum-mvp-chat-input" 
                        placeholder="Ask about dehumidifier sizing..." 
                        rows="2"
                        maxlength="400"
                    ></textarea>
                    <button id="dehum-mvp-send-button">Send</button>
                </div>
                <div class="chat-footer">
                    <small>Powered by AI • <span id="char-count">0</span>/400 characters</small>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function handle_chat_message() {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'dehum_mvp_chat_nonce')) {
            wp_send_json_error(['message' => 'Security check failed'], 403);
        }
        
        $user_input = sanitize_textarea_field($_POST['message']);
        
        // Basic input validation
        if (empty($user_input) || strlen($user_input) > 400) {
            wp_send_json_error(['message' => 'Invalid message length']);
        }
        
        // TODO: Send to n8n webhook (Step 3.1)
        // For now, return a demo response
        $demo_response = "Thanks for your message: '" . esc_html($user_input) . "'. I'm a demo response! n8n integration coming in Step 3.1.";
        
        wp_send_json_success([
            'response' => $demo_response,
            'timestamp' => current_time('mysql')
        ]);
    }
    
    public function admin_activation_notice() {
        // Only show for 24 hours after activation for Step 1.2 testing
        $activated_at = get_option('dehum_mvp_activated_at');
        if (!$activated_at) return;
        
        $activated_time = strtotime($activated_at);
        $current_time = time();
        
        // Show notice for 24 hours after activation
        if (($current_time - $activated_time) < 86400) {
            ?>
            <div class="notice notice-success is-dismissible">
                <p>
                    <strong>✅ Dehumidifier Assistant MVP</strong> is active! 
                    Visit your website frontend to see the chat button. 
                    <a href="<?php echo home_url(); ?>" target="_blank">Test it now →</a>
                </p>
            </div>
            <?php
        }
    }
    
    public function activate() {
        // Plugin activation tasks
        // TODO: Create database table (Step 5.1)
        
        // Add activation timestamp for testing
        update_option('dehum_mvp_activated_at', current_time('mysql'));
        update_option('dehum_mvp_version', DEHUM_MVP_VERSION);
        
        // Log successful activation for debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Dehumidifier Assistant MVP: Plugin activated successfully at ' . current_time('mysql'));
        }
        
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        // Plugin deactivation tasks
        
        // Log deactivation for debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Dehumidifier Assistant MVP: Plugin deactivated at ' . current_time('mysql'));
        }
        
        // Note: We keep activation timestamp for troubleshooting
        // Only delete on uninstall, not deactivation
        
        flush_rewrite_rules();
    }
}

// Initialize the plugin
new DehumidifierAssistantMVP(); 